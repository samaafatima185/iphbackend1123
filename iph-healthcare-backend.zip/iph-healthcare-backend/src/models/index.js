const User = require('./User');
const Patient = require('./Patient');
const Doctor = require('./Doctor');
const Appointment = require('./Appointment');
const Billing = require('./Billing');

// User associations
User.hasOne(Patient, { foreignKey: 'userId', as: 'patientProfile' });
User.hasOne(Doctor, { foreignKey: 'userId', as: 'doctorProfile' });

// Patient associations
Patient.belongsTo(User, { foreignKey: 'userId', as: 'account' });
Patient.hasMany(Appointment, { foreignKey: 'patientId', as: 'appointments' });
Patient.hasMany(Billing, { foreignKey: 'patientId', as: 'bills' });

// Doctor associations
Doctor.belongsTo(User, { foreignKey: 'userId', as: 'account' });
Doctor.hasMany(Appointment, { foreignKey: 'doctorId', as: 'appointments' });

// Appointment associations
Appointment.belongsTo(Patient, { foreignKey: 'patientId', as: 'patient' });
Appointment.belongsTo(Doctor, { foreignKey: 'doctorId', as: 'doctor' });
Appointment.hasOne(Billing, { foreignKey: 'appointmentId', as: 'bill' });

// Billing associations
Billing.belongsTo(Patient, { foreignKey: 'patientId', as: 'patient' });
Billing.belongsTo(Appointment, { foreignKey: 'appointmentId', as: 'appointment' });

module.exports = { User, Patient, Doctor, Appointment, Billing };
