const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const Doctor = sequelize.define('Doctor', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  userId: {
    type: DataTypes.UUID,
    allowNull: false,
    references: { model: 'users', key: 'id' },
  },
  doctorCode: {
    type: DataTypes.STRING(20),
    unique: true,
  },
  firstName: {
    type: DataTypes.STRING(50),
    allowNull: false,
  },
  lastName: {
    type: DataTypes.STRING(50),
    allowNull: false,
  },
  specialization: {
    type: DataTypes.STRING(100),
    allowNull: false,
  },
  qualification: {
    type: DataTypes.STRING(200),
  },
  phone: {
    type: DataTypes.STRING(20),
    allowNull: false,
  },
  email: {
    type: DataTypes.STRING(150),
    validate: { isEmail: true },
  },
  experience: {
    type: DataTypes.INTEGER, // years
    defaultValue: 0,
  },
  consultationFee: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0.00,
  },
  availableDays: {
    type: DataTypes.JSON, // e.g. ["Monday", "Wednesday", "Friday"]
  },
  availableTimeStart: {
    type: DataTypes.TIME,
  },
  availableTimeEnd: {
    type: DataTypes.TIME,
  },
  bio: {
    type: DataTypes.TEXT,
  },
  isActive: {
    type: DataTypes.BOOLEAN,
    defaultValue: true,
  },
}, {
  tableName: 'doctors',
  timestamps: true,
  hooks: {
    beforeCreate: async (doctor) => {
      const count = await Doctor.count();
      doctor.doctorCode = `DR-${String(count + 1).padStart(4, '0')}`;
    },
  },
});

module.exports = Doctor;
