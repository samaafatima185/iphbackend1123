const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const Billing = sequelize.define('Billing', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  invoiceNumber: {
    type: DataTypes.STRING(20),
    unique: true,
  },
  patientId: {
    type: DataTypes.UUID,
    allowNull: false,
    references: { model: 'patients', key: 'id' },
  },
  appointmentId: {
    type: DataTypes.UUID,
    allowNull: true,
    references: { model: 'appointments', key: 'id' },
  },
  consultationFee: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0.00,
  },
  medicationCharges: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0.00,
  },
  labCharges: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0.00,
  },
  otherCharges: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0.00,
  },
  discount: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0.00,
  },
  totalAmount: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
  },
  paidAmount: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0.00,
  },
  dueAmount: {
    type: DataTypes.VIRTUAL,
    get() {
      return parseFloat(this.totalAmount) - parseFloat(this.paidAmount);
    },
  },
  paymentStatus: {
    type: DataTypes.ENUM('pending', 'partial', 'paid', 'cancelled'),
    defaultValue: 'pending',
  },
  paymentMethod: {
    type: DataTypes.ENUM('cash', 'card', 'bank_transfer', 'insurance', 'other'),
  },
  paymentDate: {
    type: DataTypes.DATEONLY,
  },
  notes: {
    type: DataTypes.TEXT,
  },
}, {
  tableName: 'billing',
  timestamps: true,
  hooks: {
    beforeCreate: async (bill) => {
      const count = await Billing.count();
      const now = new Date();
      bill.invoiceNumber = `INV-${now.getFullYear()}-${String(count + 1).padStart(6, '0')}`;
    },
    beforeSave: (bill) => {
      // Auto-calculate total
      const total = parseFloat(bill.consultationFee || 0)
        + parseFloat(bill.medicationCharges || 0)
        + parseFloat(bill.labCharges || 0)
        + parseFloat(bill.otherCharges || 0)
        - parseFloat(bill.discount || 0);
      bill.totalAmount = total;

      // Auto-update payment status
      const paid = parseFloat(bill.paidAmount || 0);
      if (paid <= 0) bill.paymentStatus = 'pending';
      else if (paid < total) bill.paymentStatus = 'partial';
      else bill.paymentStatus = 'paid';
    },
  },
});

module.exports = Billing;
