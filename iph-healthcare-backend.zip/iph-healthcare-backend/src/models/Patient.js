const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const Patient = sequelize.define('Patient', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  userId: {
    type: DataTypes.UUID,
    allowNull: true, // null if walk-in patient (no system account)
    references: { model: 'users', key: 'id' },
  },
  patientCode: {
    type: DataTypes.STRING(20),
    unique: true,
  },
  firstName: {
    type: DataTypes.STRING(50),
    allowNull: false,
  },
  lastName: {
    type: DataTypes.STRING(50),
    allowNull: false,
  },
  dateOfBirth: {
    type: DataTypes.DATEONLY,
    allowNull: false,
  },
  gender: {
    type: DataTypes.ENUM('male', 'female', 'other'),
    allowNull: false,
  },
  phone: {
    type: DataTypes.STRING(20),
    allowNull: false,
  },
  email: {
    type: DataTypes.STRING(150),
    validate: { isEmail: true },
  },
  address: {
    type: DataTypes.TEXT,
  },
  bloodGroup: {
    type: DataTypes.ENUM('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'),
  },
  medicalHistory: {
    type: DataTypes.TEXT,
  },
  allergies: {
    type: DataTypes.TEXT,
  },
  emergencyContactName: {
    type: DataTypes.STRING(100),
  },
  emergencyContactPhone: {
    type: DataTypes.STRING(20),
  },
  isActive: {
    type: DataTypes.BOOLEAN,
    defaultValue: true,
  },
}, {
  tableName: 'patients',
  timestamps: true,
  hooks: {
    beforeCreate: async (patient) => {
      // Auto-generate patient code: IPH-YYYYMM-XXXX
      const now = new Date();
      const prefix = `IPH-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}`;
      const count = await Patient.count();
      patient.patientCode = `${prefix}-${String(count + 1).padStart(4, '0')}`;
    },
  },
});

module.exports = Patient;
