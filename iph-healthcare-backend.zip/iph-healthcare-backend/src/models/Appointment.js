const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const Appointment = sequelize.define('Appointment', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  appointmentCode: {
    type: DataTypes.STRING(20),
    unique: true,
  },
  patientId: {
    type: DataTypes.UUID,
    allowNull: false,
    references: { model: 'patients', key: 'id' },
  },
  doctorId: {
    type: DataTypes.UUID,
    allowNull: false,
    references: { model: 'doctors', key: 'id' },
  },
  appointmentDate: {
    type: DataTypes.DATEONLY,
    allowNull: false,
  },
  appointmentTime: {
    type: DataTypes.TIME,
    allowNull: false,
  },
  status: {
    type: DataTypes.ENUM('scheduled', 'confirmed', 'completed', 'cancelled', 'no_show'),
    defaultValue: 'scheduled',
  },
  type: {
    type: DataTypes.ENUM('consultation', 'follow_up', 'emergency', 'checkup'),
    defaultValue: 'consultation',
  },
  symptoms: {
    type: DataTypes.TEXT,
  },
  notes: {
    type: DataTypes.TEXT,
  },
  diagnosis: {
    type: DataTypes.TEXT,
  },
  prescription: {
    type: DataTypes.TEXT,
  },
  cancelReason: {
    type: DataTypes.TEXT,
  },
}, {
  tableName: 'appointments',
  timestamps: true,
  hooks: {
    beforeCreate: async (appt) => {
      const count = await Appointment.count();
      const now = new Date();
      appt.appointmentCode = `APT-${now.getFullYear()}-${String(count + 1).padStart(5, '0')}`;
    },
  },
});

module.exports = Appointment;
