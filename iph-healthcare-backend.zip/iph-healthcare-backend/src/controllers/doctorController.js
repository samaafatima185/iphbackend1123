const { Doctor, User, Appointment, Patient } = require('../models');
const { Op } = require('sequelize');

// GET /api/doctors
const getAllDoctors = async (req, res, next) => {
  try {
    const { page = 1, limit = 10, search, specialization } = req.query;
    const offset = (page - 1) * limit;

    const where = { isActive: true };
    if (search) {
      where[Op.or] = [
        { firstName: { [Op.like]: `%${search}%` } },
        { lastName: { [Op.like]: `%${search}%` } },
        { doctorCode: { [Op.like]: `%${search}%` } },
        { specialization: { [Op.like]: `%${search}%` } },
      ];
    }
    if (specialization) where.specialization = specialization;

    const { count, rows } = await Doctor.findAndCountAll({
      where,
      limit: parseInt(limit),
      offset: parseInt(offset),
      order: [['firstName', 'ASC']],
    });

    res.json({
      success: true,
      data: {
        doctors: rows,
        pagination: { total: count, page: parseInt(page), limit: parseInt(limit), pages: Math.ceil(count / limit) },
      },
    });
  } catch (error) {
    next(error);
  }
};

// GET /api/doctors/:id
const getDoctor = async (req, res, next) => {
  try {
    const doctor = await Doctor.findOne({
      where: { id: req.params.id, isActive: true },
    });
    if (!doctor) return res.status(404).json({ success: false, message: 'Doctor not found.' });
    res.json({ success: true, data: { doctor } });
  } catch (error) {
    next(error);
  }
};

// POST /api/doctors  (admin only)
const createDoctor = async (req, res, next) => {
  try {
    const { email, password, name, ...doctorData } = req.body;

    // Create User account for doctor
    const user = await User.create({ name, email, password, role: 'doctor' });
    const doctor = await Doctor.create({ ...doctorData, userId: user.id });

    res.status(201).json({ success: true, message: 'Doctor added successfully.', data: { doctor } });
  } catch (error) {
    next(error);
  }
};

// PUT /api/doctors/:id  (admin or self)
const updateDoctor = async (req, res, next) => {
  try {
    const doctor = await Doctor.findOne({ where: { id: req.params.id, isActive: true } });
    if (!doctor) return res.status(404).json({ success: false, message: 'Doctor not found.' });

    // Doctors can only update their own profile
    if (req.user.role === 'doctor' && doctor.userId !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Access denied.' });
    }

    await doctor.update(req.body);
    res.json({ success: true, message: 'Doctor updated successfully.', data: { doctor } });
  } catch (error) {
    next(error);
  }
};

// DELETE /api/doctors/:id  (admin only)
const deleteDoctor = async (req, res, next) => {
  try {
    const doctor = await Doctor.findOne({ where: { id: req.params.id, isActive: true } });
    if (!doctor) return res.status(404).json({ success: false, message: 'Doctor not found.' });

    await doctor.update({ isActive: false });
    await User.update({ isActive: false }, { where: { id: doctor.userId } });

    res.json({ success: true, message: 'Doctor removed successfully.' });
  } catch (error) {
    next(error);
  }
};

// GET /api/doctors/:id/schedule  – available time slots for a date
const getDoctorSchedule = async (req, res, next) => {
  try {
    const { date } = req.query;
    const doctor = await Doctor.findByPk(req.params.id);
    if (!doctor) return res.status(404).json({ success: false, message: 'Doctor not found.' });

    // Fetch booked appointments for the day
    const booked = await Appointment.findAll({
      where: { doctorId: doctor.id, appointmentDate: date, status: { [Op.notIn]: ['cancelled'] } },
      attributes: ['appointmentTime'],
    });
    const bookedTimes = booked.map((a) => a.appointmentTime);

    res.json({ success: true, data: { availableDays: doctor.availableDays, bookedTimes } });
  } catch (error) {
    next(error);
  }
};

module.exports = { getAllDoctors, getDoctor, createDoctor, updateDoctor, deleteDoctor, getDoctorSchedule };
