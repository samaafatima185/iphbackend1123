const { Billing, Patient, Appointment, Doctor } = require('../models');
const { Op } = require('sequelize');

const patientInclude = { model: Patient, as: 'patient', attributes: ['id', 'firstName', 'lastName', 'patientCode'] };
const appointmentInclude = { model: Appointment, as: 'appointment', attributes: ['id', 'appointmentCode', 'appointmentDate'] };

// GET /api/billing
const getAllBills = async (req, res, next) => {
  try {
    const { page = 1, limit = 10, paymentStatus, patientId, from, to } = req.query;
    const offset = (page - 1) * limit;

    const where = {};
    if (paymentStatus) where.paymentStatus = paymentStatus;
    if (patientId) where.patientId = patientId;
    if (from && to) where.createdAt = { [Op.between]: [new Date(from), new Date(to)] };

    const { count, rows } = await Billing.findAndCountAll({
      where,
      include: [patientInclude, appointmentInclude],
      limit: parseInt(limit),
      offset: parseInt(offset),
      order: [['createdAt', 'DESC']],
    });

    res.json({
      success: true,
      data: {
        bills: rows,
        pagination: { total: count, page: parseInt(page), limit: parseInt(limit), pages: Math.ceil(count / limit) },
      },
    });
  } catch (error) {
    next(error);
  }
};

// GET /api/billing/:id
const getBill = async (req, res, next) => {
  try {
    const bill = await Billing.findByPk(req.params.id, {
      include: [patientInclude, appointmentInclude],
    });
    if (!bill) return res.status(404).json({ success: false, message: 'Invoice not found.' });
    res.json({ success: true, data: { bill } });
  } catch (error) {
    next(error);
  }
};

// POST /api/billing
const createBill = async (req, res, next) => {
  try {
    const bill = await Billing.create(req.body);
    const full = await Billing.findByPk(bill.id, { include: [patientInclude] });
    res.status(201).json({ success: true, message: 'Invoice created.', data: { bill: full } });
  } catch (error) {
    next(error);
  }
};

// PUT /api/billing/:id  (update payment)
const updateBill = async (req, res, next) => {
  try {
    const bill = await Billing.findByPk(req.params.id);
    if (!bill) return res.status(404).json({ success: false, message: 'Invoice not found.' });

    await bill.update(req.body);
    res.json({ success: true, message: 'Invoice updated.', data: { bill } });
  } catch (error) {
    next(error);
  }
};

// GET /api/billing/summary  – revenue stats for dashboard
const getBillingSummary = async (req, res, next) => {
  try {
    const { sequelize } = require('../config/database');
    const { fn, col } = require('sequelize');

    const [total, paid, pending] = await Promise.all([
      Billing.sum('totalAmount'),
      Billing.sum('paidAmount'),
      Billing.sum('totalAmount', { where: { paymentStatus: 'pending' } }),
    ]);

    res.json({
      success: true,
      data: {
        totalRevenue: total || 0,
        totalCollected: paid || 0,
        totalPending: pending || 0,
        totalDue: (total || 0) - (paid || 0),
      },
    });
  } catch (error) {
    next(error);
  }
};

module.exports = { getAllBills, getBill, createBill, updateBill, getBillingSummary };
