const { Appointment, Patient, Doctor } = require('../models');
const { Op } = require('sequelize');

const doctorInclude = { model: Doctor, as: 'doctor', attributes: ['id', 'firstName', 'lastName', 'specialization', 'doctorCode'] };
const patientInclude = { model: Patient, as: 'patient', attributes: ['id', 'firstName', 'lastName', 'patientCode', 'phone'] };

// GET /api/appointments
const getAllAppointments = async (req, res, next) => {
  try {
    const { page = 1, limit = 10, status, date, doctorId, patientId } = req.query;
    const offset = (page - 1) * limit;

    const where = {};
    if (status) where.status = status;
    if (date) where.appointmentDate = date;
    if (doctorId) where.doctorId = doctorId;
    if (patientId) where.patientId = patientId;

    // Role-based filtering
    if (req.user.role === 'doctor') {
      const doctor = await Doctor.findOne({ where: { userId: req.user.id } });
      if (doctor) where.doctorId = doctor.id;
    }

    const { count, rows } = await Appointment.findAndCountAll({
      where,
      include: [doctorInclude, patientInclude],
      limit: parseInt(limit),
      offset: parseInt(offset),
      order: [['appointmentDate', 'DESC'], ['appointmentTime', 'ASC']],
    });

    res.json({
      success: true,
      data: {
        appointments: rows,
        pagination: { total: count, page: parseInt(page), limit: parseInt(limit), pages: Math.ceil(count / limit) },
      },
    });
  } catch (error) {
    next(error);
  }
};

// GET /api/appointments/today
const getTodayAppointments = async (req, res, next) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const where = { appointmentDate: today };

    if (req.user.role === 'doctor') {
      const doctor = await Doctor.findOne({ where: { userId: req.user.id } });
      if (doctor) where.doctorId = doctor.id;
    }

    const appointments = await Appointment.findAll({
      where,
      include: [doctorInclude, patientInclude],
      order: [['appointmentTime', 'ASC']],
    });

    res.json({ success: true, data: { appointments } });
  } catch (error) {
    next(error);
  }
};

// GET /api/appointments/:id
const getAppointment = async (req, res, next) => {
  try {
    const appointment = await Appointment.findByPk(req.params.id, {
      include: [doctorInclude, patientInclude],
    });
    if (!appointment) return res.status(404).json({ success: false, message: 'Appointment not found.' });
    res.json({ success: true, data: { appointment } });
  } catch (error) {
    next(error);
  }
};

// POST /api/appointments
const createAppointment = async (req, res, next) => {
  try {
    const { patientId, doctorId, appointmentDate, appointmentTime } = req.body;

    // Check for slot conflict
    const conflict = await Appointment.findOne({
      where: { doctorId, appointmentDate, appointmentTime, status: { [Op.notIn]: ['cancelled'] } },
    });
    if (conflict) {
      return res.status(409).json({ success: false, message: 'This time slot is already booked.' });
    }

    const appointment = await Appointment.create(req.body);
    const full = await Appointment.findByPk(appointment.id, { include: [doctorInclude, patientInclude] });

    res.status(201).json({ success: true, message: 'Appointment booked successfully.', data: { appointment: full } });
  } catch (error) {
    next(error);
  }
};

// PUT /api/appointments/:id
const updateAppointment = async (req, res, next) => {
  try {
    const appointment = await Appointment.findByPk(req.params.id);
    if (!appointment) return res.status(404).json({ success: false, message: 'Appointment not found.' });

    await appointment.update(req.body);
    res.json({ success: true, message: 'Appointment updated.', data: { appointment } });
  } catch (error) {
    next(error);
  }
};

// DELETE /api/appointments/:id  (cancel)
const cancelAppointment = async (req, res, next) => {
  try {
    const appointment = await Appointment.findByPk(req.params.id);
    if (!appointment) return res.status(404).json({ success: false, message: 'Appointment not found.' });

    await appointment.update({ status: 'cancelled', cancelReason: req.body.reason });
    res.json({ success: true, message: 'Appointment cancelled.' });
  } catch (error) {
    next(error);
  }
};

module.exports = { getAllAppointments, getTodayAppointments, getAppointment, createAppointment, updateAppointment, cancelAppointment };
