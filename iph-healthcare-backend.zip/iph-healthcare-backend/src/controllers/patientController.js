const { Patient, User, Appointment } = require('../models');
const { Op } = require('sequelize');

// GET /api/patients
const getAllPatients = async (req, res, next) => {
  try {
    const { page = 1, limit = 10, search, bloodGroup, gender } = req.query;
    const offset = (page - 1) * limit;

    const where = { isActive: true };
    if (search) {
      where[Op.or] = [
        { firstName: { [Op.like]: `%${search}%` } },
        { lastName: { [Op.like]: `%${search}%` } },
        { patientCode: { [Op.like]: `%${search}%` } },
        { phone: { [Op.like]: `%${search}%` } },
      ];
    }
    if (bloodGroup) where.bloodGroup = bloodGroup;
    if (gender) where.gender = gender;

    const { count, rows } = await Patient.findAndCountAll({
      where,
      limit: parseInt(limit),
      offset: parseInt(offset),
      order: [['createdAt', 'DESC']],
    });

    res.json({
      success: true,
      data: {
        patients: rows,
        pagination: { total: count, page: parseInt(page), limit: parseInt(limit), pages: Math.ceil(count / limit) },
      },
    });
  } catch (error) {
    next(error);
  }
};

// GET /api/patients/:id
const getPatient = async (req, res, next) => {
  try {
    const patient = await Patient.findOne({
      where: { id: req.params.id, isActive: true },
      include: [{ model: Appointment, as: 'appointments', limit: 5, order: [['appointmentDate', 'DESC']] }],
    });

    if (!patient) return res.status(404).json({ success: false, message: 'Patient not found.' });

    res.json({ success: true, data: { patient } });
  } catch (error) {
    next(error);
  }
};

// POST /api/patients
const createPatient = async (req, res, next) => {
  try {
    const patient = await Patient.create(req.body);
    res.status(201).json({ success: true, message: 'Patient registered successfully.', data: { patient } });
  } catch (error) {
    next(error);
  }
};

// PUT /api/patients/:id
const updatePatient = async (req, res, next) => {
  try {
    const patient = await Patient.findOne({ where: { id: req.params.id, isActive: true } });
    if (!patient) return res.status(404).json({ success: false, message: 'Patient not found.' });

    await patient.update(req.body);
    res.json({ success: true, message: 'Patient updated successfully.', data: { patient } });
  } catch (error) {
    next(error);
  }
};

// DELETE /api/patients/:id  (soft delete)
const deletePatient = async (req, res, next) => {
  try {
    const patient = await Patient.findOne({ where: { id: req.params.id, isActive: true } });
    if (!patient) return res.status(404).json({ success: false, message: 'Patient not found.' });

    await patient.update({ isActive: false });
    res.json({ success: true, message: 'Patient removed successfully.' });
  } catch (error) {
    next(error);
  }
};

module.exports = { getAllPatients, getPatient, createPatient, updatePatient, deletePatient };
