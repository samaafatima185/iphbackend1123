const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const { getAllAppointments, getTodayAppointments, getAppointment, createAppointment, updateAppointment, cancelAppointment } = require('../controllers/appointmentController');
const { authenticate, authorize } = require('../middleware/auth');
const { handleValidation } = require('../middleware/errorHandler');

const appointmentRules = [
  body('patientId').notEmpty().withMessage('Patient ID is required.'),
  body('doctorId').notEmpty().withMessage('Doctor ID is required.'),
  body('appointmentDate').isDate().withMessage('Valid appointment date is required.'),
  body('appointmentTime').notEmpty().withMessage('Appointment time is required.'),
];

router.use(authenticate);

router.get('/', getAllAppointments);
router.get('/today', getTodayAppointments);
router.get('/:id', getAppointment);
router.post('/', authorize('admin', 'receptionist', 'patient'), appointmentRules, handleValidation, createAppointment);
router.put('/:id', authorize('admin', 'doctor', 'receptionist'), updateAppointment);
router.patch('/:id/cancel', cancelAppointment);

module.exports = router;
