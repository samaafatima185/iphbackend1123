const express = require('express');
const router = express.Router();
const { getAllBills, getBill, createBill, updateBill, getBillingSummary } = require('../controllers/billingController');
const { authenticate, authorize } = require('../middleware/auth');

router.use(authenticate);
router.use(authorize('admin', 'receptionist'));

router.get('/summary', getBillingSummary);
router.get('/', getAllBills);
router.get('/:id', getBill);
router.post('/', createBill);
router.put('/:id', updateBill);

module.exports = router;
