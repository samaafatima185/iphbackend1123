const express = require('express');
const router = express.Router();
const { getAllDoctors, getDoctor, createDoctor, updateDoctor, deleteDoctor, getDoctorSchedule } = require('../controllers/doctorController');
const { authenticate, authorize } = require('../middleware/auth');

router.get('/', getAllDoctors); // Public – patients can browse doctors
router.get('/:id', getDoctor); // Public

router.use(authenticate);

router.get('/:id/schedule', getDoctorSchedule);
router.post('/', authorize('admin'), createDoctor);
router.put('/:id', authorize('admin', 'doctor'), updateDoctor);
router.delete('/:id', authorize('admin'), deleteDoctor);

module.exports = router;
