const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const { getAllPatients, getPatient, createPatient, updatePatient, deletePatient } = require('../controllers/patientController');
const { authenticate, authorize } = require('../middleware/auth');
const { handleValidation } = require('../middleware/errorHandler');

const patientRules = [
  body('firstName').trim().notEmpty().withMessage('First name is required.'),
  body('lastName').trim().notEmpty().withMessage('Last name is required.'),
  body('dateOfBirth').isDate().withMessage('Valid date of birth is required.'),
  body('gender').isIn(['male', 'female', 'other']).withMessage('Gender must be male, female, or other.'),
  body('phone').trim().notEmpty().withMessage('Phone number is required.'),
];

router.use(authenticate);

router.get('/', authorize('admin', 'doctor', 'receptionist'), getAllPatients);
router.get('/:id', authorize('admin', 'doctor', 'receptionist', 'patient'), getPatient);
router.post('/', authorize('admin', 'receptionist'), patientRules, handleValidation, createPatient);
router.put('/:id', authorize('admin', 'receptionist'), updatePatient);
router.delete('/:id', authorize('admin'), deletePatient);

module.exports = router;
