# IPH Healthcare – Backend API

Node.js + Express REST API for the IPH Healthcare Management System.

---

## 🗂 Project Structure

```
iph-healthcare-backend/
├── src/
│   ├── config/
│   │   └── database.js          # Sequelize + MySQL connection
│   ├── controllers/
│   │   ├── authController.js    # Register, login, me, change-password
│   │   ├── patientController.js # CRUD for patients
│   │   ├── doctorController.js  # CRUD for doctors + schedule
│   │   ├── appointmentController.js
│   │   └── billingController.js
│   ├── middleware/
│   │   ├── auth.js              # JWT authenticate + authorize(roles)
│   │   └── errorHandler.js      # Validation + global error handler
│   ├── models/
│   │   ├── index.js             # All associations
│   │   ├── User.js
│   │   ├── Patient.js
│   │   ├── Doctor.js
│   │   ├── Appointment.js
│   │   └── Billing.js
│   ├── routes/
│   │   ├── authRoutes.js
│   │   ├── patientRoutes.js
│   │   ├── doctorRoutes.js
│   │   ├── appointmentRoutes.js
│   │   └── billingRoutes.js
│   ├── app.js                   # Express app setup
│   └── server.js                # Entry point
├── .env.example
├── .gitignore
└── package.json
```

---

## ⚙️ Setup

### 1. Clone & Install
```bash
git clone https://github.com/YOUR_USERNAME/iph-healthcare-backend.git
cd iph-healthcare-backend
npm install
```

### 2. Configure Environment
```bash
cp .env.example .env
# Edit .env with your MySQL credentials and JWT secret
```

### 3. Create MySQL Database
```sql
CREATE DATABASE iph_healthcare CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 4. Run
```bash
npm run dev     # Development (nodemon)
npm start       # Production
```

Tables are auto-created via Sequelize sync on first run.

---

## 🔑 Roles & Access

| Role           | Access                                           |
|----------------|--------------------------------------------------|
| `admin`        | Full access to all modules                       |
| `doctor`       | View patients, manage own appointments           |
| `receptionist` | Manage patients, appointments, billing           |
| `patient`      | View own data, book appointments                 |

---

## 📡 API Endpoints

### Auth – `/api/auth`
| Method | Path                  | Auth     | Description          |
|--------|-----------------------|----------|----------------------|
| POST   | `/register`           | No       | Register new user    |
| POST   | `/login`              | No       | Login, get JWT       |
| GET    | `/me`                 | ✅       | Get current user     |
| PUT    | `/change-password`    | ✅       | Change password      |

### Patients – `/api/patients`
| Method | Path   | Roles                          |
|--------|--------|--------------------------------|
| GET    | `/`    | admin, doctor, receptionist    |
| GET    | `/:id` | admin, doctor, receptionist, patient |
| POST   | `/`    | admin, receptionist            |
| PUT    | `/:id` | admin, receptionist            |
| DELETE | `/:id` | admin                          |

### Doctors – `/api/doctors`
| Method | Path             | Auth     | Roles               |
|--------|------------------|----------|---------------------|
| GET    | `/`              | No       | Public              |
| GET    | `/:id`           | No       | Public              |
| GET    | `/:id/schedule`  | ✅       | All logged-in       |
| POST   | `/`              | ✅       | admin               |
| PUT    | `/:id`           | ✅       | admin, doctor (own) |
| DELETE | `/:id`           | ✅       | admin               |

### Appointments – `/api/appointments`
| Method | Path          | Roles                              |
|--------|---------------|------------------------------------|
| GET    | `/`           | All authenticated                  |
| GET    | `/today`      | All authenticated                  |
| GET    | `/:id`        | All authenticated                  |
| POST   | `/`           | admin, receptionist, patient       |
| PUT    | `/:id`        | admin, doctor, receptionist        |
| PATCH  | `/:id/cancel` | All authenticated                  |

### Billing – `/api/billing`
| Method | Path       | Roles                    |
|--------|------------|--------------------------|
| GET    | `/summary` | admin, receptionist      |
| GET    | `/`        | admin, receptionist      |
| GET    | `/:id`     | admin, receptionist      |
| POST   | `/`        | admin, receptionist      |
| PUT    | `/:id`     | admin, receptionist      |

---

## 🧪 Testing with Postman

1. **Login:** `POST /api/auth/login` → copy `token`
2. **Set header:** `Authorization: Bearer <token>`
3. **Test:** `GET /api/patients`

Health check (no auth): `GET /health`

---

## 📦 Module Ownership (Team Division)

| Module            | Suggested Assignee |
|-------------------|--------------------|
| Auth & Users      | Member 1           |
| Patients          | Member 2           |
| Doctors           | Member 3           |
| Appointments      | Member 4           |
| Billing           | Member 5           |

---

## 🔧 Tech Stack

- **Runtime:** Node.js 18+
- **Framework:** Express 4
- **ORM:** Sequelize 6
- **Database:** MySQL 8
- **Auth:** JWT + bcryptjs
- **Validation:** express-validator
- **Security:** helmet, cors, express-rate-limit
